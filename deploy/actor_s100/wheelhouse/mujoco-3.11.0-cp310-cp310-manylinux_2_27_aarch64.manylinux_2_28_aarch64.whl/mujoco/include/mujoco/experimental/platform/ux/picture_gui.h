// Copyright 2025 DeepMind Technologies Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef MUJOCO_SRC_EXPERIMENTAL_PLATFORM_UX_PICTURE_GUI_H_
#define MUJOCO_SRC_EXPERIMENTAL_PLATFORM_UX_PICTURE_GUI_H_

#include <vector>

#include <mujoco/mujoco.h>
#include "experimental/platform/hal/renderer.h"

namespace mujoco::platform {

// Manages the state of a single picture-in-picture widget.
struct PipState {
  enum Mode { Color, Depth, Segmentation };
  int camera = 0;
  int texture = 0;
  Mode mode = Color;
};

// Renders the GUI for a set of picture-in-picture widgets.
void PipGui(const mjModel* model, mjData* data, float aspect_ratio,
            platform::Renderer* renderer, std::vector<PipState>* pips);

}  // namespace mujoco::platform

#endif  // MUJOCO_SRC_EXPERIMENTAL_PLATFORM_UX_PICTURE_GUI_H_
