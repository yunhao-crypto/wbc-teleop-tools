# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter
from aorta.sysmon.CollectorError import CollectorError as _type_0
from aorta.sysmon.DiskStat import DiskStat as _type_1
from aorta.sysmon.MetricCapability import MetricCapability as _type_2
from aorta.sysmon.NetIfStat import NetIfStat as _type_3
from aorta.sysmon.ProcessStat import ProcessStat as _type_4
from aorta.sysmon.PsiLine import PsiLine as _type_5
from aorta.sysmon.SysmonSnapshot import SysmonSnapshot as _type_6

_reader_0 = TableVectorReader(_type_0, (
    ('observed_at_ns', 8, 'Q', 0, True, _type_0.ObservedAtNs),
))

_reader_1 = TableVectorReader(_type_1, (
    ('read_bytes_per_sec', 6, 'Q', 0, True, _type_1.ReadBytesPerSec),
    ('write_bytes_per_sec', 8, 'Q', 0, True, _type_1.WriteBytesPerSec),
    ('read_ios_per_sec', 10, 'Q', 0, True, _type_1.ReadIosPerSec),
    ('write_ios_per_sec', 12, 'Q', 0, True, _type_1.WriteIosPerSec),
    ('discard_bytes_per_sec', 14, 'Q', 0, True, _type_1.DiscardBytesPerSec),
    ('discard_ios_per_sec', 16, 'Q', 0, True, _type_1.DiscardIosPerSec),
    ('inflight_reads', 18, 'Q', 0, True, _type_1.InflightReads),
    ('inflight_writes', 20, 'Q', 0, True, _type_1.InflightWrites),
    ('await_ms', 22, 'f', 0.0, True, _type_1.AwaitMs),
    ('util_percent', 24, 'f', 0.0, True, _type_1.UtilPercent),
    ('avg_queue_length', 26, 'f', 0.0, True, _type_1.AvgQueueLength),
    ('logical_block_size', 28, 'I', 512, True, _type_1.LogicalBlockSize),
))

_reader_2 = TableVectorReader(_type_2, (
    ('configured_mode', 6, 'B', 2, True, _type_2.ConfiguredMode),
    ('runtime_status', 8, 'B', 1, True, _type_2.RuntimeStatus),
    ('perf_raw_count', 14, 'Q', 0, True, _type_2.PerfRawCount),
    ('perf_time_enabled_ns', 16, 'Q', 0, True, _type_2.PerfTimeEnabledNs),
    ('perf_time_running_ns', 18, 'Q', 0, True, _type_2.PerfTimeRunningNs),
))

_reader_3 = TableVectorReader(_type_3, (
    ('rx_bytes_per_sec', 6, 'Q', 0, True, _type_3.RxBytesPerSec),
    ('rx_packets_per_sec', 8, 'Q', 0, True, _type_3.RxPacketsPerSec),
    ('tx_bytes_per_sec', 10, 'Q', 0, True, _type_3.TxBytesPerSec),
    ('tx_packets_per_sec', 12, 'Q', 0, True, _type_3.TxPacketsPerSec),
    ('rx_errors', 14, 'Q', 0, True, _type_3.RxErrors),
    ('rx_drop', 16, 'Q', 0, True, _type_3.RxDrop),
    ('tx_errors', 18, 'Q', 0, True, _type_3.TxErrors),
    ('tx_drop', 20, 'Q', 0, True, _type_3.TxDrop),
    ('mtu', 24, 'I', 0, True, _type_3.Mtu),
    ('speed_mbps', 26, 'i', -1, True, _type_3.SpeedMbps),
))

_reader_4 = TableVectorReader(_type_4, (
    ('pid', 4, 'i', 0, True, _type_4.Pid),
    ('starttime_ticks', 16, 'Q', 0, True, _type_4.StarttimeTicks),
    ('thread_count', 18, 'I', 0, True, _type_4.ThreadCount),
    ('cpu_user_us_delta', 20, 'Q', 0, True, _type_4.CpuUserUsDelta),
    ('cpu_kernel_us_delta', 22, 'Q', 0, True, _type_4.CpuKernelUsDelta),
    ('cpu_children_us_delta', 24, 'Q', 0, True, _type_4.CpuChildrenUsDelta),
    ('cpu_percent_host', 26, 'f', 0.0, True, _type_4.CpuPercentHost),
    ('cpu_percent_per_core', 28, 'f', 0.0, True, _type_4.CpuPercentPerCore),
    ('vss_bytes', 30, 'Q', 0, True, _type_4.VssBytes),
    ('rss_bytes', 32, 'Q', 0, True, _type_4.RssBytes),
    ('rss_hwm_bytes', 34, 'Q', 0, True, _type_4.RssHwmBytes),
    ('minor_faults_per_sec', 36, 'Q', 0, True, _type_4.MinorFaultsPerSec),
    ('major_faults_per_sec', 38, 'Q', 0, True, _type_4.MajorFaultsPerSec),
    ('voluntary_ctxt_switches_per_sec', 40, 'Q', 0, True, _type_4.VoluntaryCtxtSwitchesPerSec),
    ('nonvoluntary_ctxt_switches_per_sec', 42, 'Q', 0, True, _type_4.NonvoluntaryCtxtSwitchesPerSec),
    ('read_bytes_per_sec', 44, 'Q', 0, True, _type_4.ReadBytesPerSec),
    ('write_bytes_per_sec', 46, 'Q', 0, True, _type_4.WriteBytesPerSec),
    ('cancelled_write_bytes', 48, 'Q', 0, True, _type_4.CancelledWriteBytes),
    ('fd_count', 50, 'q', -1, True, _type_4.FdCount),
    ('oom_score', 52, 'i', 0, True, _type_4.OomScore),
    ('oom_score_adj', 54, 'i', 0, True, _type_4.OomScoreAdj),
    ('exit_marker', 56, '?', False, True, _type_4.ExitMarker),
))

_reader_5 = TableVectorReader(_type_5, (
    ('avg10', 8, 'f', 0.0, True, _type_5.Avg10),
    ('avg60', 10, 'f', 0.0, True, _type_5.Avg60),
    ('avg300', 12, 'f', 0.0, True, _type_5.Avg300),
    ('total_us', 14, 'Q', 0, True, _type_5.TotalUs),
    ('total_delta_us', 16, 'Q', 0, True, _type_5.TotalDeltaUs),
    ('stall_ratio', 18, 'f', 0.0, True, _type_5.StallRatio),
))


def read_capabilities(root, fields=None):
    if not isinstance(root, _type_6):
        raise TypeError('expected aorta.sysmon.SysmonSnapshot')
    return _reader_2.rows(root, 26, fields)


def read_collector_errors(root, fields=None):
    if not isinstance(root, _type_6):
        raise TypeError('expected aorta.sysmon.SysmonSnapshot')
    return _reader_0.rows(root, 28, fields)


def read_disks(root, fields=None):
    if not isinstance(root, _type_6):
        raise TypeError('expected aorta.sysmon.SysmonSnapshot')
    return _reader_1.rows(root, 34, fields)


def read_net_ifs(root, fields=None):
    if not isinstance(root, _type_6):
        raise TypeError('expected aorta.sysmon.SysmonSnapshot')
    return _reader_3.rows(root, 36, fields)


def read_psi(root, fields=None):
    if not isinstance(root, _type_6):
        raise TypeError('expected aorta.sysmon.SysmonSnapshot')
    return _reader_5.rows(root, 38, fields)


def read_processes(root, fields=None):
    if not isinstance(root, _type_6):
        raise TypeError('expected aorta.sysmon.SysmonSnapshot')
    return _reader_4.rows(root, 40, fields)
