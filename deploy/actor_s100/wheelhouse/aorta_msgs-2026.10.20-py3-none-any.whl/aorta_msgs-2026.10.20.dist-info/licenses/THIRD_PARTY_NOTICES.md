# Third-party notices

Generated for the `aorta_msgs` distribution from its ownership manifest.
The `flatbuffers` runtime is a declared dependency (Requires-Dist), not part
of this distribution.

## Foxglove-derived schemas — MIT

The modules below are generated from FlatBuffers schemas converted or adapted
from the foxglove-sdk (https://github.com/foxglove/foxglove-sdk,
`schemas/flatbuffer`), Copyright (c) Foxglove Technologies Inc, MIT License.
The verbatim upstream license text follows and is also shipped beside this
file as `THIRD_PARTY_LICENSES/foxglove-sdk.LICENSE`.

Schemas:
- message/schemas/topic/foxglove_schema/CameraCalibration.fbs
- message/schemas/topic/foxglove_schema/CompressedImage.fbs
- message/schemas/topic/foxglove_schema/CompressedVideo.fbs
- message/schemas/topic/foxglove_schema/FrameTransform.fbs
- message/schemas/topic/foxglove_schema/FrameTransforms.fbs
- message/schemas/topic/foxglove_schema/LaserScan.fbs
- message/schemas/topic/foxglove_schema/Log.fbs
- message/schemas/topic/foxglove_schema/PackedElementField.fbs
- message/schemas/topic/foxglove_schema/Point2.fbs
- message/schemas/topic/foxglove_schema/Point3.fbs
- message/schemas/topic/foxglove_schema/PointCloud.fbs
- message/schemas/topic/foxglove_schema/Pose.fbs
- message/schemas/topic/foxglove_schema/Quaternion.fbs
- message/schemas/topic/foxglove_schema/RawAudio.fbs
- message/schemas/topic/foxglove_schema/RawImage.fbs
- message/schemas/topic/foxglove_schema/Time.fbs
- message/schemas/topic/foxglove_schema/Vector2.fbs
- message/schemas/topic/foxglove_schema/Vector3.fbs

Generated modules:
- CameraCalibration_schema_meta.py
- CompressedImage_schema_meta.py
- CompressedVideo_schema_meta.py
- FrameTransforms_schema_meta.py
- LaserScan_schema_meta.py
- Log_schema_meta.py
- PointCloud_schema_meta.py
- RawAudio_schema_meta.py
- RawImage_schema_meta.py
- foxglove/CameraCalibration.py
- foxglove/CompressedImage.py
- foxglove/CompressedVideo.py
- foxglove/FrameTransform.py
- foxglove/FrameTransforms.py
- foxglove/LaserScan.py
- foxglove/Log.py
- foxglove/LogLevel.py
- foxglove/NumericType.py
- foxglove/PackedElementField.py
- foxglove/Point2.py
- foxglove/Point3.py
- foxglove/PointCloud.py
- foxglove/PointCloud_fastpath.py
- foxglove/Pose.py
- foxglove/Quaternion.py
- foxglove/RawAudio.py
- foxglove/RawImage.py
- foxglove/RegionOfInterest.py
- foxglove/Time.py
- foxglove/Vector2.py
- foxglove/Vector3.py

### License text

MIT License

Copyright (c) Foxglove Technologies Inc

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
