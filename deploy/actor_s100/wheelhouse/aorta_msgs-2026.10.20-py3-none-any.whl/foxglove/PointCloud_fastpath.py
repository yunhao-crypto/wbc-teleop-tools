# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter
from foxglove.PackedElementField import PackedElementField as _type_0
from foxglove.PointCloud import PointCloud as _type_1

_reader_0 = TableVectorReader(_type_0, (
    ('offset', 6, 'I', 0, True, _type_0.Offset),
    ('type', 8, 'B', 0, True, _type_0.Type),
))


def read_fields(root, fields=None):
    if not isinstance(root, _type_1):
        raise TypeError('expected foxglove.PointCloud')
    return _reader_0.rows(root, 12, fields)
