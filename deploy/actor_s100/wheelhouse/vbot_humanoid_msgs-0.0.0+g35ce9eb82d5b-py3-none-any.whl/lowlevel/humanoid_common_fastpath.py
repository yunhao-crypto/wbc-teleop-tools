# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

CommandKeyVector = StructVectorWriter(16, 8, (
    ('session_id', 0, 'Q'),
    ('sequence', 8, 'Q'),
))

SampleRefVector = StructVectorWriter(32, 8, (
    ('stream', 0, 'B'),
    ('side', 1, 'B'),
    ('sample_id', 8, 'Q'),
    ('source_time_us', 16, 'Q'),
    ('validity', 24, 'B'),
))
