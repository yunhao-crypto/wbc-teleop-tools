# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

BodyJointCapabilityVector = StructVectorWriter(48, 4, (
    ('body_index', 0, 'H'),
    ('slot_role', 2, 'B'),
    ('is_mock', 3, '?'),
    ('supported_fields', 4, 'H'),
    ('valid_limits', 6, 'H'),
    ('q_min', 8, 'f'),
    ('q_max', 12, 'f'),
    ('dq_min', 16, 'f'),
    ('dq_max', 20, 'f'),
    ('tau_min', 24, 'f'),
    ('tau_max', 28, 'f'),
    ('kp_min', 32, 'f'),
    ('kp_max', 36, 'f'),
    ('kd_min', 40, 'f'),
    ('kd_max', 44, 'f'),
))
from lowlevel.BodyInfo import BodyInfo as _type_0
from lowlevel.BodyMotorIdentity import BodyMotorIdentity as _type_1
from lowlevel.EndEffectorCapability import EndEffectorCapability as _type_2
from lowlevel.RobotInfo import RobotInfo as _type_3

_reader_0 = TableVectorReader(_type_1, (
    ('node_id', 6, 'I', 0, True, _type_1.NodeId),
    ('present', 8, '?', False, True, _type_1.Present),
))

_reader_1 = TableVectorReader(_type_2, (
    ('side', 4, 'B', 0, True, _type_2.Side),
    ('is_mock', 6, '?', False, True, _type_2.IsMock),
    ('ready', 10, '?', False, True, _type_2.Ready),
    ('status', 12, 'b', 3, True, _type_2.Status),
))


def read_motor_identities(root, fields=None):
    if not isinstance(root, _type_0):
        raise TypeError('expected lowlevel.BodyInfo')
    return _reader_0.rows(root, 12, fields)


def read_end_effectors(root, fields=None):
    if not isinstance(root, _type_3):
        raise TypeError('expected lowlevel.RobotInfo')
    return _reader_1.rows(root, 12, fields)
