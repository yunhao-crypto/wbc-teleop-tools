# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

AxisCommandVector = StructVectorWriter(28, 4, (
    ('command_fields', 0, 'I'),
    ('mode', 4, 'H'),
    ('pos', 8, 'f'),
    ('vel', 12, 'f'),
    ('vel_limit', 16, 'f'),
    ('tau', 20, 'f'),
    ('current', 24, 'f'),
))

AxisStateVector = StructVectorWriter(28, 4, (
    ('valid_fields', 0, 'I'),
    ('pos', 4, 'f'),
    ('vel', 8, 'f'),
    ('tau', 12, 'f'),
    ('current', 16, 'f'),
    ('temperature_c', 20, 'f'),
    ('error_code', 24, 'I'),
))

CommandKeyVector = StructVectorWriter(16, 8, (
    ('session_id', 0, 'Q'),
    ('sequence', 8, 'Q'),
))

RegionStampVector = StructVectorWriter(48, 8, (
    ('sample_seq', 0, 'I'),
    ('ts_request_us', 8, 'Q'),
    ('ts_acquired_hw_us', 16, 'Q'),
    ('ts_source_us', 24, 'Q'),
    ('ts_ingested_us', 32, 'Q'),
    ('status_flags', 40, 'H'),
    ('direction_flags', 42, 'H'),
    ('validity', 44, 'B'),
))

SampleRefVector = StructVectorWriter(32, 8, (
    ('stream', 0, 'B'),
    ('side', 1, 'B'),
    ('sample_id', 8, 'Q'),
    ('source_time_us', 16, 'Q'),
    ('validity', 24, 'B'),
))
