# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter
from lowlevel.ee.EndEffectorInfo import EndEffectorInfo as _type_0
from lowlevel.ee.TouchRegionInfo import TouchRegionInfo as _type_1

_reader_0 = TableVectorReader(_type_1, (
    ('region_id', 4, 'H', 0, True, _type_1.RegionId),
    ('sensor_type', 10, 'H', 0, True, _type_1.SensorType),
    ('dtype', 16, 'B', 0, True, _type_1.Dtype),
    ('payload_offset', 20, 'I', 0, True, _type_1.PayloadOffset),
    ('payload_bytes', 22, 'I', 0, True, _type_1.PayloadBytes),
    ('encoding_version', 24, 'H', 0, True, _type_1.EncodingVersion),
    ('geometry_valid', 28, '?', False, True, _type_1.GeometryValid),
))


def read_touch_regions(root, fields=None):
    if not isinstance(root, _type_0):
        raise TypeError('expected lowlevel.ee.EndEffectorInfo')
    return _reader_0.rows(root, 56, fields)
