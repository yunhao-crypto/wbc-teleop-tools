# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

HumanoidRelativeMotorCmdVector = StructVectorWriter(24, 4, (
    ('mode', 0, 'B'),
    ('q', 4, 'f'),
    ('dq', 8, 'f'),
    ('tau', 12, 'f'),
    ('kp', 16, 'f'),
    ('kd', 20, 'f'),
))
from lowlevel.HumanoidLowState import HumanoidLowState as _type_0
from lowlevel.HumanoidMotorState import HumanoidMotorState as _type_1
from lowlevel.ImuSample import ImuSample as _type_2

_reader_0 = TableVectorReader(_type_1, (
    ('ts_acquired_hw_us', 4, 'Q', 0, True, _type_1.TsAcquiredHwUs),
    ('ts_ingested_us', 6, 'Q', 0, True, _type_1.TsIngestedUs),
    ('ts_assembled_us', 8, 'Q', 0, True, _type_1.TsAssembledUs),
    ('mode', 10, 'B', 0, True, _type_1.Mode),
    ('q', 12, 'f', 0.0, True, _type_1.Q),
    ('dq', 14, 'f', 0.0, True, _type_1.Dq),
    ('ddq', 16, 'f', 0.0, True, _type_1.Ddq),
    ('tau_est', 18, 'f', 0.0, True, _type_1.TauEst),
    ('q_raw', 20, 'f', 0.0, True, _type_1.QRaw),
    ('dq_raw', 22, 'f', 0.0, True, _type_1.DqRaw),
    ('ddq_raw', 24, 'f', 0.0, True, _type_1.DdqRaw),
    ('temperature', 26, 'b', 0, True, _type_1.Temperature),
    ('lost', 28, 'I', 0, True, _type_1.Lost),
    ('slot_index', 30, 'B', 0, True, _type_1.SlotIndex),
    ('slot_role', 32, 'B', 0, True, _type_1.SlotRole),
    ('accumulated_running_sec', 34, 'I', 0, True, _type_1.AccumulatedRunningSec),
    ('overload_integral', 38, 'h', -32768, True, _type_1.OverloadIntegral),
    ('mos_temperature_deg_c', 40, 'h', -32768, True, _type_1.MosTemperatureDegC),
    ('iq_setpoint_a', 42, 'f', 0.0, True, _type_1.IqSetpointA),
    ('iq_measured_a', 44, 'f', 0.0, True, _type_1.IqMeasuredA),
))

_reader_1 = TableVectorReader(_type_2, (
    ('ts_sampled_us', 4, 'Q', 0, True, _type_2.TsSampledUs),
    ('ts_acquired_hw_us', 6, 'Q', 0, True, _type_2.TsAcquiredHwUs),
    ('ts_ingested_us', 8, 'Q', 0, True, _type_2.TsIngestedUs),
    ('ts_assembled_us', 10, 'Q', 0, True, _type_2.TsAssembledUs),
    ('location', 12, 'B', 0, True, _type_2.Location),
    ('status', 16, 'B', 0, True, _type_2.Status),
    ('temperature_deg_c', 18, 'f', 0.0, True, _type_2.TemperatureDegC),
    ('device_timestamp_ms', 20, 'Q', 0, True, _type_2.DeviceTimestampMs),
    ('host_timestamp_us', 22, 'Q', 0, True, _type_2.HostTimestampUs),
))


def read_imu_states(root, fields=None):
    if not isinstance(root, _type_0):
        raise TypeError('expected lowlevel.HumanoidLowState')
    return _reader_1.rows(root, 6, fields)


def read_motor_states(root, fields=None):
    if not isinstance(root, _type_0):
        raise TypeError('expected lowlevel.HumanoidLowState')
    return _reader_0.rows(root, 8, fields)
