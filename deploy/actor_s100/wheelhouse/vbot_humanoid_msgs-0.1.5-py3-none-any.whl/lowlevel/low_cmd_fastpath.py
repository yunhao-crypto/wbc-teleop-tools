# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

BmsCmdVector = StructVectorWriter(1, 1, (
    ('off', 0, 'B'),
))
