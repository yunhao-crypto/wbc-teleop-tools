# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

BodyJointStateVector = StructVectorWriter(40, 8, (
    ('ts_acquired_hw_us', 0, 'Q'),
    ('ts_ingested_us', 8, 'Q'),
    ('ts_assembled_us', 16, 'Q'),
    ('q', 24, 'f'),
    ('dq', 28, 'f'),
    ('tau_est', 32, 'f'),
    ('error_code', 36, 'I'),
))
from lowlevel.BodyImuSample import BodyImuSample as _type_0
from lowlevel.BodyState import BodyState as _type_1

_reader_0 = TableVectorReader(_type_0, (
    ('ts_sampled_us', 4, 'Q', 0, True, _type_0.TsSampledUs),
    ('ts_acquired_hw_us', 6, 'Q', 0, True, _type_0.TsAcquiredHwUs),
    ('ts_ingested_us', 8, 'Q', 0, True, _type_0.TsIngestedUs),
    ('ts_assembled_us', 10, 'Q', 0, True, _type_0.TsAssembledUs),
    ('location', 12, 'B', 0, True, _type_0.Location),
    ('status', 16, 'B', 0, True, _type_0.Status),
))


def read_imu_states(root, fields=None):
    if not isinstance(root, _type_1):
        raise TypeError('expected lowlevel.BodyState')
    return _reader_0.rows(root, 20, fields)
