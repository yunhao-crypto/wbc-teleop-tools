# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

BodyJointCapabilityVector = StructVectorWriter(52, 4, (
    ('body_index', 0, 'H'),
    ('slot_role', 2, 'B'),
    ('is_mock', 3, '?'),
    ('populated', 4, '?'),
    ('supported_fields', 6, 'H'),
    ('valid_limits', 8, 'H'),
    ('q_min', 12, 'f'),
    ('q_max', 16, 'f'),
    ('dq_min', 20, 'f'),
    ('dq_max', 24, 'f'),
    ('tau_min', 28, 'f'),
    ('tau_max', 32, 'f'),
    ('kp_min', 36, 'f'),
    ('kp_max', 40, 'f'),
    ('kd_min', 44, 'f'),
    ('kd_max', 48, 'f'),
))
from lowlevel.BodyInfo import BodyInfo as _type_0
from lowlevel.BodyMotorIdentity import BodyMotorIdentity as _type_1
from lowlevel.EndEffectorCapability import EndEffectorCapability as _type_2
from lowlevel.RobotInfo import RobotInfo as _type_3

_reader_0 = TableVectorReader(_type_1, (
    ('node_id', 6, 'I', 0, True, _type_1.NodeId),
    ('present', 8, '?', False, True, _type_1.Present),
))

_reader_1 = TableVectorReader(_type_2, (
    ('side', 4, 'B', 0, True, _type_2.Side),
    ('kind', 6, 'B', 0, True, _type_2.Kind),
    ('configured', 8, '?', False, True, _type_2.Configured),
    ('is_mock', 10, '?', False, True, _type_2.IsMock),
    ('ready', 16, '?', False, True, _type_2.Ready),
    ('status', 18, 'b', 3, True, _type_2.Status),
))


def read_motor_identities(root, fields=None):
    if not isinstance(root, _type_0):
        raise TypeError('expected lowlevel.BodyInfo')
    return _reader_0.rows(root, 12, fields)


def read_end_effectors(root, fields=None):
    if not isinstance(root, _type_3):
        raise TypeError('expected lowlevel.RobotInfo')
    return _reader_1.rows(root, 12, fields)
