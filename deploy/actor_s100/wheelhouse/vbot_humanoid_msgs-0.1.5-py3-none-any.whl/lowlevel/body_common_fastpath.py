# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

BodyJointCmdVector = StructVectorWriter(20, 4, (
    ('q', 0, 'f'),
    ('dq', 4, 'f'),
    ('tau', 8, 'f'),
    ('kp', 12, 'f'),
    ('kd', 16, 'f'),
))

RootQuatWxyzVector = StructVectorWriter(16, 4, (
    ('w', 0, 'f'),
    ('x', 4, 'f'),
    ('y', 8, 'f'),
    ('z', 12, 'f'),
))
