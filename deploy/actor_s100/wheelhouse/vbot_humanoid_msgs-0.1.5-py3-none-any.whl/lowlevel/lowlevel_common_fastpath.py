# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

MotorCmdVector = StructVectorWriter(24, 4, (
    ('mode', 0, 'B'),
    ('q', 4, 'f'),
    ('dq', 8, 'f'),
    ('tau', 12, 'f'),
    ('kp', 16, 'f'),
    ('kd', 20, 'f'),
))

MotorStateVector = StructVectorWriter(40, 4, (
    ('mode', 0, 'B'),
    ('q', 4, 'f'),
    ('dq', 8, 'f'),
    ('ddq', 12, 'f'),
    ('tau_est', 16, 'f'),
    ('q_raw', 20, 'f'),
    ('dq_raw', 24, 'f'),
    ('ddq_raw', 28, 'f'),
    ('temperature', 32, 'b'),
    ('lost', 36, 'I'),
))
