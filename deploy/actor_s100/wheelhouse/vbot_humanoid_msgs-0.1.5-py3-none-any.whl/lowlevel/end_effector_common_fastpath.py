# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

FingerTouchMetaVector = StructVectorWriter(32, 8, (
    ('ts_request_us', 0, 'Q'),
    ('ts_acquired_hw_us', 8, 'Q'),
    ('ts_ingested_us', 16, 'Q'),
    ('sample_seq', 24, 'I'),
    ('status_flags', 28, 'H'),
    ('direction_flags', 30, 'H'),
))

HandCmdTraceEventVector = StructVectorWriter(64, 8, (
    ('session_id', 0, 'Q'),
    ('sequence', 8, 'Q'),
    ('ts_received_us', 16, 'Q'),
    ('ts_accepted_us', 24, 'Q'),
    ('ts_first_output_us', 32, 'Q'),
    ('ts_write_ack_us', 40, 'Q'),
    ('ts_first_feedback_us', 48, 'Q'),
    ('cmd_id', 56, 'H'),
    ('reject_code', 58, 'H'),
    ('stage', 60, 'B'),
))

HandJointCmdVector = StructVectorWriter(8, 4, (
    ('q', 0, 'f'),
    ('dq', 4, 'f'),
))

HandJointStateVector = StructVectorWriter(28, 4, (
    ('q', 0, 'f'),
    ('dq', 4, 'f'),
    ('current_ma', 8, 'f'),
    ('q_cmd', 12, 'f'),
    ('dq_cmd', 16, 'f'),
    ('q_raw', 20, 'h'),
    ('dq_raw', 22, 'h'),
    ('current_raw', 24, 'h'),
    ('status_raw', 26, 'B'),
))
