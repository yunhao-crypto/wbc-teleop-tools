# Generated from BFBS and matching pinned flatc getters.
from aorta_msgs_runtime._table_vector import TableVectorReader
from aorta_msgs_runtime._struct_vector import StructVectorWriter

GripperHostTargetVector = StructVectorWriter(8, 4, (
    ('q', 0, 'f'),
    ('torque_cmd_nm', 4, 'f'),
))

GripperSampleVector = StructVectorWriter(12, 4, (
    ('q', 0, 'f'),
    ('reported_torque_nm', 4, 'f'),
    ('status_raw', 8, 'B'),
))
